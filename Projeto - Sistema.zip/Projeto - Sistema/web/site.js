document.addEventListener('DOMContentLoaded', () => {
    const audio = document.getElementById('audio');
    const janela = document.querySelector('.janela');

    if (janela) {
        janela.style.animation = "abrirJanela 0.25s ease-out forwards";
    }

    const acceptButton = document.querySelector('#aceitarBtn');
    const loginButton = document.querySelector('#loginBtn');  // Corrigido
    const cadastroButton = document.querySelector('#cadastroBtn');

    if (acceptButton) {
        acceptButton.addEventListener('click', () => {
            audio.currentTime = 0;
            audio.play();
            document.querySelector('#janelaBemVindo').style.display = 'none';
            document.querySelector('#janelaAceito').style.display = 'block';
        });
    }

    if (loginButton) {
        loginButton.addEventListener('click', () => {
            audio.currentTime = 0;
            audio.play();
            document.querySelector('#janelaAceito').style.display = 'none';
            document.querySelector('#janelaLogin').style.display = 'block';
        });
    }

    if (cadastroButton) {
        cadastroButton.addEventListener('click', () => {
            audio.currentTime = 0;
            audio.play();
            document.querySelector('#janelaAceito').style.display = 'none';
            document.querySelector('#janelaCadastro').style.display = 'block';
        });
    }
});
